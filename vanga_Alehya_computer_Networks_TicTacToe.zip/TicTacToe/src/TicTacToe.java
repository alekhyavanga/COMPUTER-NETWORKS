import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Random;
import java.io.*;
import java.net.*;

public class TicTacToe extends JFrame implements ChangeListener, ActionListener {
  private JSlider slider;

  private Board board;
  private int lineThickness=8;
  private Color oColor=Color.RED, xColor=Color.BLUE;
  static final char BLANK=' ', O='O', X='X';
  private final char position[]={  // Board position (BLANK, O, or X)
    BLANK, BLANK, BLANK,
    BLANK, BLANK, BLANK,
    BLANK, BLANK, BLANK};
    private int WINS=0, LOOSES=0, DRAWS=0;  // game count by user
    private final static int  DEST_PORT = 6523;
    private final static String SERVER_NAME = new String("localhost");
    private int r;
    private int pos;  
    
    
  // Start the game
  public static void main(String args[]) {
    new TicTacToe();
  }

  // Initialising the game
  public TicTacToe() {
    super("Tic Tac Toe");
    JPanel topPanel=new JPanel();
        add(topPanel, BorderLayout.NORTH);
    add(board=new Board(), BorderLayout.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(750, 500);
    setVisible(true);
  }

  // Changing the line thickness
  public void stateChanged(ChangeEvent e) {}

  // Changing the colour of O or X
  public void actionPerformed(ActionEvent e) {}

  // Game is displayed and it represents the board what it actually plays
  private class Board extends JPanel implements MouseListener {
    private Random random=new Random();
    private int rows[][]={{0,2},{3,5},{6,8},{0,6},{1,7},{2,8},{0,8},{2,6}};
      // Endpoints of the 8 rows in position[] (across, down, diagonally)

    public Board() {
      addMouseListener(this);
    }

    // Board will be redrawn
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      int w=getWidth();
      int h=getHeight();
      Graphics2D g2d = (Graphics2D) g;

      // Draw the grid
      g2d.setPaint(Color.BLACK);
      g2d.fill(new Rectangle2D.Double(0, 0, w, h));
      g2d.setPaint(Color.YELLOW);
      g2d.setStroke(new BasicStroke(lineThickness));
      g2d.draw(new Line2D.Double(0, h/3, w, h/3));
      g2d.draw(new Line2D.Double(0, h*2/3, w, h*2/3));
      g2d.draw(new Line2D.Double(w/3, 0, w/3, h));
      g2d.draw(new Line2D.Double(w*2/3, 0, w*2/3, h));

      // Draw the Os and Xs
      for (int i=0; i<9; ++i) {
        double xpos=(i%3+0.5)*w/3.0;
        double ypos=(i/3+0.5)*h/3.0;
        double xr=w/8.0;
        double yr=h/8.0;
        if (position[i]==O) {
          g2d.setPaint(oColor);
          g2d.draw(new Ellipse2D.Double(xpos-xr, ypos-yr, xr*2, yr*2));
        }
        else if (position[i]==X) {
          g2d.setPaint(xColor);
          g2d.draw(new Line2D.Double(xpos-xr, ypos-yr, xpos+xr, ypos+yr));
          g2d.draw(new Line2D.Double(xpos-xr, ypos+yr, xpos+xr, ypos-yr));
        }
      }
    }

    // Draw an O where the mouse is clicked
    public void mouseClicked(MouseEvent e) {
      int xpos=e.getX()*3/getWidth();
      int ypos=e.getY()*3/getHeight();
       pos=xpos+3*ypos;
      if (pos>=0 && pos<9 && position[pos]==BLANK) {
        position[pos]=O;
        System.out.println("YOUR MOVE:"+pos);
        repaint();
        connect();
        putX();  // computer plays
        repaint();
      }
    }

    // Ignore other mouse events
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    void connect() {
        try{
           
        
        InetAddress dstIP = InetAddress.getByName(SERVER_NAME);
			
			//Create local socket and connect to server
			Socket clientSocket = new Socket(dstIP, DEST_PORT);
			
			//Read text from Keyboard
			BufferedReader kbdReader = new BufferedReader(new InputStreamReader(System.in));
			//System.out.println("Enter text in lower case:");
			
			int inputString = pos;
				
			//Get the input and output streams of the socket
			PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
		
			BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			
			//write the bytes out to the server
			out.println(inputString);
			
			//read reply from server as a byte stream
		//	String serverReply = in.readLine();			
			
            		//new String(serverReply));
        }
        
        catch (Exception e)
		{
			e.printStackTrace();
		}

    }
    
    
    
    
    // Computer plays X
    void putX() {
      
      // Check if game is over
      if (won(O))
        newGame(O);
      else if (isDraw())
        newGame(BLANK);

      // Play X, possibly ending the game
      else {
        nextMove();
        if (won(X))
          newGame(X);
        else if (isDraw())
          newGame(BLANK);
      }
    }

    // Return true if player has won
    boolean won(char player) {
      for (int i=0; i<8; ++i)
        if (testRow(player, rows[i][0], rows[i][1]))
          return true;
      return false;
    }

    // Has player won in the row from position[a] to position[b]?
    boolean testRow(char player, int a, int b) {
      return position[a]==player && position[b]==player 
          && position[(a+b)/2]==player;
    }

    // Play X in the best spot
    void nextMove() {
       r=findRow(X);  // complete a row of X and win if possible
      if (r<0)
        r=findRow(O);  // or try to block O from winning
      if (r<0) {  // otherwise move randomly
        do
          r=random.nextInt(9);
        while (position[r]!=BLANK);
      }
      position[r]=X;
      System.out.println("COMPUTER MOVE: " + r );
      connect();
    }

    // Return 0-8 for the position of a blank spot in a row if the
    // other 2 spots are occupied by player, or -1 if no spot exists
    int findRow(char player) {
      for (int i=0; i<8; ++i) {
        int result=find1Row(player, rows[i][0], rows[i][1]);
        if (result>=0)
          return result;
      }
      return -1;
    }

    // If 2 of 3 spots in the row from position[a] to position[b]
    // are occupied by player and the third is blank, then return the
    // index of the blank spot, else return -1.
    int find1Row(char player, int a, int b) {
      int c=(a+b)/2;  // middle spot
      if (position[a]==player && position[b]==player && position[c]==BLANK)
        return c;
      if (position[a]==player && position[c]==player && position[b]==BLANK)
        return b;
      if (position[b]==player && position[c]==player && position[a]==BLANK)
        return a;
      return -1;
    }

    // Are all 9 spots filled?
    boolean isDraw() {
      for (int i=0; i<9; ++i)
        if (position[i]==BLANK)
          return false;
      return true;
    }

    // Start a new game
    void newGame(char winner) {
      repaint();

      // Announce result of last game.  Ask user to play again.
      String result;
      if (winner==O) {
        ++WINS;
        result = "You Win!";
      }
      else if (winner==X) {
        ++LOOSES;
        result = "I Win!";
      }
      else {
        result = "Tie";
        ++DRAWS;
      }
      if (JOptionPane.showConfirmDialog(null, 
          "YOU HAVE "+WINS+ " WINS, "+LOOSES+" LOOSES, "+DRAWS+" DRAWS\n"
          +"PLAY AGAIN?", result, JOptionPane.YES_NO_OPTION)
          !=JOptionPane.YES_OPTION) {
        System.exit(0);
      }

      // To start a new game the board will be cleared
      for (int j=0; j<9; ++j)
        position[j]=BLANK;

      // Computer starts first every other game
      if ((WINS+LOOSES+DRAWS)%2 == 1)
        nextMove();
    }
  } 
} // end class TicTacToe